"""
Version information for PyGraphviz, created during installation.

Do not add this file to the repository.

"""

__version__ = '1.5'
__revision__ = None
__date__ = 'Mon Sep 10 15:18:40 2018'

