/*
 * Custom preprocessor macros for Win build, defined by cfati.
 *
 * !!! @TODO: This file is included by (MODIFIED) user_settings.h !!!
 */

//#pragma once  // Preferred, by stay in sync.
#if !defined(_USER_SETTINGS_CFATI_H_)
#define _USER_SETTINGS_CFATI_H_


#  define WOLFSSL_TLS13

#  define HAVE_FFDHE_2048
#  define HAVE_FFDHE_3072
#  define HAVE_FFDHE_4096
#  define HAVE_FFDHE_6144
#  define HAVE_FFDHE_8192

#  define HAVE_HKDF
#  define WC_RSA_PSS

#  define WOLFSSL_ALLOW_TLSV10

#  define WOLFSSL_BASE64_ENCODE

#  define WOLFSSL_SHA224
#  define WOLFSSL_SHA3
#  define WOLFSSL_SHAKE256
#  define HAVE_BLAKE2
#  define HAVE_BLAKE2B
#  define HAVE_BLAKE2S

#  define HAVE_POLY1305
#  define HAVE_ONE_TIME_AUTH

#  define HAVE_CHACHA

#  define TFM_ECC256
#  define TFM_TIMING_RESISTANT

#  define WOLFSSL_IPV6

#  define HAVE_ALPN

#  define WOLFSSL_DTLS

#  define USE_FAST_MATH


#endif  // _USER_SETTINGS_CFATI_H_
