#pragma once

// @TODO: !!! CREATED by cfati !!!
// Included by every (MODIFIED) .h file declaring DATA to be exported

#if defined(_WIN32)
#  if defined(LIBBEARSSL_STATIC)
#    define LIBBEARSSL_EXPORT_API
#  else
#    if defined(LIBBEARSSL_EXPORTS)
#      define LIBBEARSSL_EXPORT_API __declspec(dllexport)
#    else
#      define LIBBEARSSL_EXPORT_API __declspec(dllimport)
#    endif
#  endif
#else
#  define LIBBEARSSL_EXPORT_API
#endif

// Lame workaround (gainarie)
#define EXTERN_CONST_EXPORT LIBBEARSSL_EXPORT_API extern const
